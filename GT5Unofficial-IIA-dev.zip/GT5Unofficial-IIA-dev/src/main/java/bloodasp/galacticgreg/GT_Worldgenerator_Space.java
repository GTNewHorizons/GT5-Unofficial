package bloodasp.galacticgreg;

import gregtech.common.GT_Worldgenerator;

public class GT_Worldgenerator_Space extends GT_Worldgenerator {
    public GT_Worldgenerator_Space() {
        super();
    }
}
