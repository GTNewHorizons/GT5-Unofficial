package gregtech.common.blocks;

import net.minecraft.block.Block;

public class GT_Item_Casings3
        extends GT_Item_Casings_Abstract {
    public GT_Item_Casings3(Block par1) {
        super(par1);
    }
}
