package gregtech.common.blocks;

import net.minecraft.block.Block;

public class GT_Item_Granites
        extends GT_Item_Stones_Abstract {
    public GT_Item_Granites(Block par1) {
        super(par1);
    }
}
