package gregtech.api.interfaces.internal;


public interface IUETileEntity /*extends IElectrical*/ {
    //
}