package gregtech.api.interfaces.internal;

import net.minecraft.item.crafting.IRecipe;

public interface IGT_CraftingRecipe extends IRecipe {
    public boolean isRemovable();
}
