package gregtech.api.interfaces.internal;

/**
 * A simple compound Interface for generic BuildCraft Code.
 */
public interface IBCTileEntity /*extends IPowerReceptor*/ {
    //
}