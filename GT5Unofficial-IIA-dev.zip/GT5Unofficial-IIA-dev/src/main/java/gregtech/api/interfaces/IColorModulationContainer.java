package gregtech.api.interfaces;

public interface IColorModulationContainer {
    public short[] getRGBA();
}
